# Traffic Sign Recognition Using CNN and Keras

This project uses Convolutional Neural Networks (CNN) and Keras to recognize traffic signs.

## Features
- CNN with multiple layers and data augmentation.
- Dataset containing 58 traffic sign classes.
- Easy to train and evaluate models.

## Installation
Install dependencies with:
```bash
pip install -r requirements.txt
```

## Dataset

Download and unzip the dataset into the data/traffic-sign-dataset/.

## Usage

To train the model, run:

```bash
python main.py
```

## Results

The model achieves high accuracy in recognizing traffic signs.
